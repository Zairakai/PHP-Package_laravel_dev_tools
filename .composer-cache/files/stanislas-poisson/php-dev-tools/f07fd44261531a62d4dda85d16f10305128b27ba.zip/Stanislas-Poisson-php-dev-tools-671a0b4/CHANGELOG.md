# Changelog

All notable changes are listed here. The format follows [Keep a Changelog](https://keepachangelog.com/), and the project follows [Semantic Versioning](https://semver.org/) from the version 0.1.0. See "Versioning" in the README for what the public API is.

## 1.0.1 - 2026-10-06

### Added

- A documentation site on GitHub Pages: the guide (the README) and the reference of every class, read from the source, for each released version ([#20](https://github.com/Stanislas-Poisson/php-dev-tools/issues/20)).

### Changed

- The release workflow checks the format of the tag and handles the pre-releases ([#18](https://github.com/Stanislas-Poisson/php-dev-tools/issues/18)).

## 1.0.0 - 2026-10-03

The first stable version. It holds what the version `0.2.0` was going to hold, which was never tagged.

### Changed

- The hook `commit-msg` follows the commit convention of the zairakai handbook, which is the only one of the zairakai tools: `type(scope): #TICKET subject`, with the types of the handbook, a ticket that is mandatory, a first line of 72 characters at most and a blank second line. It no longer accepts `WIP` alone, and no longer asks for a lowercase subject of 10 characters ([#15](https://github.com/Stanislas-Poisson/php-dev-tools/issues/15)).
- PHP 8.3 is the lowest version, like in KMark, PPTX-Enigma and French-Postal-Code-Package ([#9](https://github.com/Stanislas-Poisson/php-dev-tools/issues/9)). A project that needs PHP 8.2 stays on `0.1.x`.
- The constants are typed.

### Fixed

- The hook `prepare-commit-msg` put the ticket of the branch in front of the message, which the hook `commit-msg` refused. The ticket now goes after the `type(scope):` of the message, also with `git commit -m` ([#11](https://github.com/Stanislas-Poisson/php-dev-tools/issues/11)).

## 0.1.0 - 2026-10-03

The first release.

### Added

- The base configurations of Pint, PHPStan, Rector, PHP Insights and markdownlint, which a project extends ([#3](https://github.com/Stanislas-Poisson/php-dev-tools/issues/3)).
- The command `php-dev-tools`: `cs`, `cs:fix`, `analyse`, `rector`, `rector:fix`, `insights`, `markdown`, `quality`, `quality:fast`, `quality:fix`, `init` and `hooks`.
- The Git hooks `commit-msg`, `pre-commit`, `pre-push` and `prepare-commit-msg`, and a `Makefile.inc`.
