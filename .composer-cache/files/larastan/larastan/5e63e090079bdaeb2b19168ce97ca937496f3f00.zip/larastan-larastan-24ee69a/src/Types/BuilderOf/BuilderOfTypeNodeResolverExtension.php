<?php

declare(strict_types=1);

namespace Larastan\Larastan\Types\BuilderOf;

use Illuminate\Database\Eloquent\Model;
use Larastan\Larastan\Methods\BuilderHelper;
use PHPStan\Analyser\NameScope;
use PHPStan\PhpDoc\TypeNodeResolver;
use PHPStan\PhpDoc\TypeNodeResolverAwareExtension;
use PHPStan\PhpDoc\TypeNodeResolverExtension;
use PHPStan\PhpDocParser\Ast\Type\GenericTypeNode;
use PHPStan\PhpDocParser\Ast\Type\TypeNode;
use PHPStan\Type\NeverType;
use PHPStan\Type\ObjectType;
use PHPStan\Type\Type;

use function count;

final class BuilderOfTypeNodeResolverExtension implements TypeNodeResolverExtension, TypeNodeResolverAwareExtension
{
    private TypeNodeResolver $typeNodeResolver;

    public function __construct(private BuilderHelper $builderHelper)
    {
    }

    public function resolve(TypeNode $typeNode, NameScope $nameScope): Type|null
    {
        if (! $typeNode instanceof GenericTypeNode) {
            return null;
        }

        if ($typeNode->type->name !== 'builder-of') {
            return null;
        }

        if (count($typeNode->genericTypes) < 1 || count($typeNode->genericTypes) > 2) {
            return null;
        }

        $genericType = $this->typeNodeResolver->resolve($typeNode->genericTypes[0], $nameScope);

        if ((new ObjectType(Model::class))->isSuperTypeOf($genericType)->no()) {
            return null;
        }

        if ($genericType instanceof NeverType) {
            return null;
        }

        $relationType = isset($typeNode->genericTypes[1])
            ? $this->typeNodeResolver->resolve($typeNode->genericTypes[1], $nameScope)
            : null;

        if ($relationType !== null && (! $relationType->isString()->yes() || $relationType instanceof NeverType)) {
            return null;
        }

        return new BuilderOfType($genericType, $this->builderHelper, $relationType);
    }

    public function setTypeNodeResolver(TypeNodeResolver $typeNodeResolver): void
    {
        $this->typeNodeResolver = $typeNodeResolver;
    }
}
