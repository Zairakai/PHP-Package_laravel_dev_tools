<?php

declare(strict_types=1);

namespace RectorLaravel\Set\Packages\Faker;

final class FakerSetList
{
    public const string FAKER_10 = __DIR__ . '/../../../../config/sets/packages/faker/faker-10.php';
}
