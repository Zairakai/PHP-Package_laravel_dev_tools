<?php

declare(strict_types=1);

use Rector\Config\RectorConfig;

return static function (RectorConfig $rectorConfig): void {
    $rectorConfig->import(__DIR__ . '/laravel130-core.php');
    $rectorConfig->import(__DIR__ . '/laravel130-attributes.php');
};
