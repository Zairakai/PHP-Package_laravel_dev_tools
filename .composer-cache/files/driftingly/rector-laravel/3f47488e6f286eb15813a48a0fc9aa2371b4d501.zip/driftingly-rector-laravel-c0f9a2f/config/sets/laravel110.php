<?php

declare(strict_types=1);

use Rector\Config\RectorConfig;
use RectorLaravel\Rector\Class_\ModelCastsPropertyToCastsMethodRector;
use RectorLaravel\Rector\Class_\ReplaceQueueTraitsWithQueueableRector;
use RectorLaravel\Rector\MethodCall\AssertSeeToAssertSeeHtmlRector;
use RectorLaravel\Rector\MethodCall\RefactorBlueprintGeometryColumnsRector;

// see https://laravel.com/docs/11.x/upgrade
return static function (RectorConfig $rectorConfig): void {
    $rectorConfig->import(__DIR__ . '/../config.php');

    // https://github.com/laravel/framework/pull/47237
    $rectorConfig->rule(ModelCastsPropertyToCastsMethodRector::class);

    // https://github.com/laravel/framework/pull/49634
    $rectorConfig->rule(RefactorBlueprintGeometryColumnsRector::class);

    // https://github.com/laravel/framework/pull/52285
    $rectorConfig->rule(AssertSeeToAssertSeeHtmlRector::class);

    // https://github.com/laravel/framework/commit/b397704f8a5bae532bd03fa4acf8aa08cd40c4e7
    $rectorConfig->rule(ReplaceQueueTraitsWithQueueableRector::class);
};
